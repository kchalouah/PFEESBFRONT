import { Component } from "@angular/core"
import { CommonModule } from "@angular/common"
import { RouterOutlet, RouterModule } from "@angular/router"
import { MatToolbarModule } from "@angular/material/toolbar"
import { MatButtonModule } from "@angular/material/button"
import { MatIconModule } from "@angular/material/icon"
import { MatSidenavModule } from "@angular/material/sidenav"
import { MatListModule } from "@angular/material/list"
import { MatMenuModule } from "@angular/material/menu"
import  { AuthService } from "./services/auth.service"

@Component({
  selector: "app-root",
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    RouterModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatSidenavModule,
    MatListModule,
    MatMenuModule,
  ],
  template: `
    <div class="app-container">
      <mat-sidenav-container class="sidenav-container" *ngIf="authService.isAuthenticated()">
        <mat-sidenav #drawer class="sidenav" fixedInViewport mode="over">
          <mat-toolbar color="primary">
            <span>Menu</span>
          </mat-toolbar>
          <mat-nav-list>
            <a mat-list-item routerLink="/dashboard" (click)="drawer.close()">
              <mat-icon>dashboard</mat-icon>
              <span>Tableau de bord</span>
            </a>
            <a mat-list-item routerLink="/users" (click)="drawer.close()">
              <mat-icon>people</mat-icon>
              <span>Utilisateurs</span>
            </a>
            <a mat-list-item routerLink="/ilots" (click)="drawer.close()">
              <mat-icon>business</mat-icon>
              <span>Îlots</span>
            </a>
            <a mat-list-item routerLink="/machines" (click)="drawer.close()">
              <mat-icon>precision_manufacturing</mat-icon>
              <span>Machines</span>
            </a>
            <a mat-list-item routerLink="/programmes" (click)="drawer.close()">
              <mat-icon>schedule</mat-icon>
              <span>Programmes</span>
            </a>
            <a mat-list-item routerLink="/demandes" (click)="drawer.close()">
              <mat-icon>assignment</mat-icon>
              <span>Demandes</span>
            </a>
            <a mat-list-item routerLink="/metiers" (click)="drawer.close()">
              <mat-icon>work</mat-icon>
              <span>Métiers</span>
            </a>
          </mat-nav-list>
        </mat-sidenav>

        <mat-sidenav-content>
          <mat-toolbar color="primary">
            <button mat-icon-button (click)="drawer.toggle()">
              <mat-icon>menu</mat-icon>
            </button>
            <span>PFE Aziz - Gestion</span>
            <span class="spacer"></span>
            <button mat-icon-button [matMenuTriggerFor]="userMenu">
              <mat-icon>account_circle</mat-icon>
            </button>
            <mat-menu #userMenu="matMenu">
              <button mat-menu-item (click)="logout()">
                <mat-icon>logout</mat-icon>
                <span>Déconnexion</span>
              </button>
            </mat-menu>
          </mat-toolbar>

          <main class="main-content">
            <router-outlet></router-outlet>
          </main>
        </mat-sidenav-content>
      </mat-sidenav-container>

      <!-- Show router outlet directly for auth pages -->
      <router-outlet *ngIf="!authService.isAuthenticated()"></router-outlet>
    </div>
  `,
  styles: [
    `
    .app-container {
      height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .sidenav-container {
      height: 100%;
    }

    .sidenav {
      width: 280px;
      border-right: none;
      box-shadow: 2px 0 8px var(--shadow-color);
    }

    .sidenav .mat-toolbar {
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .mat-toolbar {
      position: sticky;
      top: 0;
      z-index: 2;
      box-shadow: 0 2px 8px var(--shadow-color);
    }

    .mat-nav-list a {
      margin: 8px 12px;
      border-radius: 6px;
      transition: all 0.2s ease;
    }

    .mat-nav-list a:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    .mat-nav-list a mat-icon {
      margin-right: 12px;
    }

    .main-content {
      padding: 24px;
      background-color: var(--background-light);
      min-height: calc(100vh - 64px);
    }

    .spacer {
      flex: 1 1 auto;
    }
  `,
  ],
})
export class AppComponent {
  constructor(public authService: AuthService) {}

  logout() {
    this.authService.logout()
  }
}
