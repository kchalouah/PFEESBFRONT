// This file is deprecated. Please use src/main.ts instead.
// This file will be removed in a future update.
