export interface Metier {
  id?: number
  name: string
  description?: string
  category?: string
  requiredSkills?: string[]
  createdAt?: Date
  updatedAt?: Date
}
